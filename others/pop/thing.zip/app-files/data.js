var APP_DATA = {
  "scenes": [
    {
      "id": "0-beach1-facebook-6500px",
      "name": "Beach1 facebook 6500px",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1625,
      "initialViewParameters": {
        "yaw": -2.0603164052043503,
        "pitch": 0.21569069378168848,
        "fov": 0.7159407657113782
      },
      "linkHotspots": [
        {
          "yaw": 1.578693738104005,
          "pitch": 0.11864363970068403,
          "rotation": 0,
          "target": "0-beach1-facebook-6500px"
        },
        {
          "yaw": -0.40796516523181126,
          "pitch": 0.10017026780679217,
          "rotation": 7.853981633974483,
          "target": "0-beach1-facebook-6500px"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": true
  }
};
